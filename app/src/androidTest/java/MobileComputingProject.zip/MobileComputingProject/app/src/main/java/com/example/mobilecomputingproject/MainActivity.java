package com.example.mobilecomputingproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.INTERNET},200);

        Button create_rubric_b    = findViewById(R.id.create_rubric_button);
        Button edit_rubric_b      = findViewById(R.id.edit_rubric_button);
        Button grade_test_b       = findViewById(R.id.grade_test_button);
        Button view_edit_grades_b = findViewById(R.id.edit_view_grades_button);

        create_rubric_b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent cRubricIntent = new Intent(MainActivity.this, createRubricActivity.class);
                startActivity(cRubricIntent);
            }
        });

        edit_rubric_b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent eRubricIntent = new Intent(MainActivity.this, edit_gradeTestSelActivity.class);
                eRubricIntent.putExtra("mode", "edit");
                startActivity(eRubricIntent);
            }
        });

        grade_test_b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent gTestIntent = new Intent(MainActivity.this, edit_gradeTestSelActivity.class);
                gTestIntent.putExtra("mode", "grade");
                startActivity(gTestIntent);
            }
        });
    }
}
