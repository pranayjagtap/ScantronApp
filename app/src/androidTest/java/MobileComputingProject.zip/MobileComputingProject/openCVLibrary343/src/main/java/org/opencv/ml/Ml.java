//
// This file is auto-generated. Please don't modify it!
//
package org.opencv.ml;



// C++: class Ml
//javadoc: Ml

public class Ml {

    public static final int
            VAR_NUMERICAL = 0,
            VAR_ORDERED = 0,
            VAR_CATEGORICAL = 1,
            TEST_ERROR = 0,
            TRAIN_ERROR = 1,
            ROW_SAMPLE = 0,
            COL_SAMPLE = 1;




}
