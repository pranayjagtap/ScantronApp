package com.example.mobilecomputingproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;


import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import java.util.ArrayList;

public class answerKeyActivity extends AppCompatActivity {

    ListView simpleList;
    int[] questions;
    Button backButton;
    Button forwardButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer_key);
        //Get info from old intent
        Intent oldIntent = getIntent();
        SharedPreferences prefs_meta = getSharedPreferences("datastore", MODE_PRIVATE);
        SharedPreferences.Editor editor_meta = getSharedPreferences("datastore", MODE_PRIVATE).edit();

        final String nameTest = oldIntent.getStringExtra("nameOfTest");
        System.out.println("Test name = " + nameTest);
        final int num = oldIntent.getIntExtra("numOfQuestions", 0);
        editor_meta.putInt(nameTest+"-numOfQuestions",num);
        editor_meta.apply();

        questions = new int[num];
        System.out.println("Number of questions = " + num);
        final boolean multiAnswers = oldIntent.getBooleanExtra("multiAnswers", false);
        editor_meta.putBoolean(nameTest+"-multiAnswers",multiAnswers);
        editor_meta.apply();
        final boolean partialCredit = oldIntent.getBooleanExtra("partialCredit", false);
        editor_meta.putBoolean(nameTest+"-partialCredit",partialCredit);
        editor_meta.apply();
        //Create array of question numbers
        for (int i = 1; i <= num; i++){
            questions[i-1] = i;
            System.out.println("questions[" + (i-1) +"] = " + questions[i-1]);
        }


        //Get list view
        simpleList = (ListView) findViewById(R.id.my_list);


        final CustomAdapterMulti customAdapter1 = new CustomAdapterMulti(getApplicationContext(), questions);
        final CustomAdapterSingle customAdapter2 = new CustomAdapterSingle(getApplicationContext(), questions);
        //Create custom adapter based on options selected
        if(multiAnswers) {
            simpleList.setAdapter(customAdapter1);
        } else {
            simpleList.setAdapter(customAdapter2);
        }
        backButton = findViewById(R.id.backButtonNav);
        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent mainIntent = new Intent(answerKeyActivity.this, createRubricActivity.class);
                startActivity(mainIntent);
            }
        });
        forwardButton = findViewById(R.id.forwardButtonNav);
        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Test name = " + nameTest);
                System.out.println("Number of Questions = " + num);
                System.out.println("mutipleAnswers = " + multiAnswers);
                System.out.println("partialCredit = " + partialCredit);
                String message = "";
                //Storing rubrics
                StringBuilder result = new StringBuilder();

                //Store rubrics locally as hashtable in key value pair
                SharedPreferences prefs = getSharedPreferences("datastore", MODE_PRIVATE);
                SharedPreferences.Editor editor = getSharedPreferences("datastore", MODE_PRIVATE).edit();






                if(multiAnswers) {

                    // get the value of selected answers from custom adapter
                    for (int i = 0; i < customAdapter1.selectedAnswers.size(); i++) {
                        message = message + "\n" + (i + 1) + " " + customAdapter1.selectedAnswers.get(i);
                        result.append(i+1+":"+customAdapter1.selectedAnswers.get(i)+","); //Pranay added
                    }
                    // display the message on screen with the help of Toast.
                    Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
                } else {
                    for (int i = 0; i < customAdapter2.selectedAnswers.size(); i++) {
                        message = message + "\n" + (i + 1) + " " + customAdapter2.selectedAnswers.get(i);
                        result.append(i+1+":"+customAdapter1.selectedAnswers.get(i)+","); //Pranay Added
                    }
                    // display the message on screen with the help of Toast.
                    Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
                }
                editor.putString(nameTest,result.toString());
                editor.apply();

                SharedPreferences prefsget = getSharedPreferences("datastore", MODE_PRIVATE);
                String trycount = prefsget.getString(nameTest, "");//"No name defined" is the default value.
                System.out.println("here here");
                System.out.println(trycount);

                //Intent newIntent = new Intent(createRubricActivity.this, answerKeyActivity.class);
                //newIntent.putExtra("nameOfTest", nameTest);
                //newIntent.putExtra("numOfQuestions", num);
                //newIntent.putExtra("multiAnswers", multiAnswers);
                //newIntent.putExtra("partialCredit", partialCredit);
                //startActivity(newIntent);
            }
        });

    }


}
