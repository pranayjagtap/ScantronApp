package com.example.mobilecomputingproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapterMulti extends BaseAdapter {
    Context context;
    int[] questions;
    LayoutInflater inflater;
    String selected = "";
    public static ArrayList<String> selectedAnswers;

    public CustomAdapterMulti(Context applicationContext, int[] questions) {
        this.context = applicationContext;
        this.questions = questions;
        selectedAnswers = new ArrayList<>();
        for(int i = 0; i < questions.length; i ++) {
            selectedAnswers.add("Not Entered");
        }
        inflater = (LayoutInflater.from(applicationContext));
    }

    public int getCount() {
        return questions.length;
    }

    public Object getItem(int i) {
        return null;
    }

    public long getItemId(int i) {
        return 0;
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.question_layout_multi, null);
        // get the reference of TextView and Button's
        TextView question = (TextView) view.findViewById(R.id.QuestionNum);
        CheckBox A = (CheckBox) view.findViewById(R.id.checkA);
        CheckBox B = (CheckBox) view.findViewById(R.id.checkB);
        CheckBox C = (CheckBox) view.findViewById(R.id.checkC);
        CheckBox D = (CheckBox) view.findViewById(R.id.checkD);
        CheckBox E = (CheckBox) view.findViewById(R.id.checkE);
        // perform setOnCheckedChangeListener event on A button
        A.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String temp = selectedAnswers.get(i);
                int g;
                // set Yes values in ArrayList if RadioButton is checked
                if (isChecked) {
                    g = temp.indexOf("A");
                    if (g == -1) {
                        temp = temp + "A";
                    }
                    selectedAnswers.set(i, temp);
                } else {
                    g = temp.indexOf("A");
                    if(g != -1) {
                        temp = temp.replace("A", "");
                    }
                    selectedAnswers.set(i, temp);
                }
            }
        });
        // perform setOnCheckedChangeListener event on B button
        B.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String temp = selectedAnswers.get(i);
                int g;
                // set B values in ArrayList if RadioButton is checked
                if (isChecked) {
                    g = temp.indexOf("B");
                    if (g == -1) {
                        temp = temp + "B";
                    }
                    selectedAnswers.set(i, temp);
                } else {
                    g = temp.indexOf("B");
                    if(g != -1) {
                        temp = temp.replace("B", "");
                    }
                    selectedAnswers.set(i, temp);
                }

            }
        });
        // perform setOnCheckedChangeListener event on C button
        C.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String temp = selectedAnswers.get(i);
                int g;
                // set C values in ArrayList if RadioButton is checked
                if (isChecked) {
                    g = temp.indexOf("C");
                    if (g == -1) {
                        temp = temp + "C";
                    }
                    selectedAnswers.set(i, temp);
                } else {
                    g = temp.indexOf("C");
                    if(g != -1) {
                        temp = temp.replace("C", "");
                    }
                    selectedAnswers.set(i, temp);
                }
            }
        });
        // perform setOnCheckedChangeListener event on D button
        D.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String temp = selectedAnswers.get(i);
                int g;
                // set D values in ArrayList if RadioButton is checked
                if (isChecked) {
                    g = temp.indexOf("D");
                    if (g == -1) {
                        temp = temp + "D";
                    }
                    selectedAnswers.set(i, temp);
                } else {
                    g = temp.indexOf("D");
                    if(g != -1) {
                        temp = temp.replace("D", "");
                    }
                    selectedAnswers.set(i, temp);
                }
            }
        });
        // perform setOnCheckedChangeListener event on E button
        E.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                String temp = selectedAnswers.get(i);
                int g;
                // set E values in ArrayList if RadioButton is checked
                if (isChecked) {
                    g = temp.indexOf("E");
                    if (g == -1) {
                        temp = temp + "E";
                    }
                    selectedAnswers.set(i, temp);
                } else {
                    g = temp.indexOf("E");
                    if(g != -1) {
                        temp = temp.replace("E", "");
                    }
                    selectedAnswers.set(i, temp);
                }
            }
        });
        selectedAnswers.set(i, selected);
// set the value in TextView
        question.setText(""+questions[i]);
        return view;
    }
}
