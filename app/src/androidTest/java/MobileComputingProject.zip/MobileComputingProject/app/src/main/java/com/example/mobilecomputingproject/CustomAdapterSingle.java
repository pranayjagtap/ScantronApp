package com.example.mobilecomputingproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapterSingle extends BaseAdapter {
    Context context;
    int[] questions;
    LayoutInflater inflater;
    String selected = "";
    public static ArrayList<String> selectedAnswers;

    public CustomAdapterSingle(Context applicationContext, int[] questions) {
        this.context = applicationContext;
        this.questions = questions;
        selectedAnswers = new ArrayList<>();
        for(int i = 0; i < questions.length; i ++) {
            selectedAnswers.add("Not Entered");
        }
        inflater = (LayoutInflater.from(applicationContext));
    }

    public int getCount() {
        return questions.length;
    }

    public Object getItem(int i) {
        return null;
    }

    public long getItemId(int i) {
        return 0;
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.question_layout_single, null);
        // get the reference of TextView and Button's
        TextView question = (TextView) view.findViewById(R.id.QuestionNum);
        RadioButton A = (RadioButton) view.findViewById(R.id.radioA);
        RadioButton B = (RadioButton) view.findViewById(R.id.radioB);
        RadioButton C = (RadioButton) view.findViewById(R.id.radioC);
        RadioButton D = (RadioButton) view.findViewById(R.id.radioD);
        RadioButton E = (RadioButton) view.findViewById(R.id.radioE);
        // perform setOnCheckedChangeListener event on A button
        A.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // set Yes values in ArrayList if RadioButton is checked
                if (isChecked)
                    selectedAnswers.set(i, "A");
            }
        });
        // perform setOnCheckedChangeListener event on B button
        B.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // set No values in ArrayList if RadioButton is checked
                if (isChecked)
                    selectedAnswers.set(i, "B");

            }
        });
        // perform setOnCheckedChangeListener event on C button
        C.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // set Yes values in ArrayList if RadioButton is checked
                if (isChecked)
                    selectedAnswers.set(i, "C");
            }
        });
        // perform setOnCheckedChangeListener event on D button
        D.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // set Yes values in ArrayList if RadioButton is checked
                if (isChecked)
                    selectedAnswers.set(i, "D");
            }
        });
        // perform setOnCheckedChangeListener event on E button
        E.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // set Yes values in ArrayList if RadioButton is checked
                if (isChecked)
                    selectedAnswers.set(i, "E");
            }
        });
        // set the value in TextView
        question.setText(""+questions[i]);
        return view;
    }
}
